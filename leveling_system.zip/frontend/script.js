
let userXP = 0;  // Points d'XP de l'utilisateur
let userLevel = 1;  // Niveau de l'utilisateur

// Fonction pour mettre à jour l'interface
function updateProgress() {
    let progress = (userXP % 100) / 100 * 100;
    document.getElementById("user-xp").textContent = userXP;
    document.getElementById("user-level").textContent = userLevel;
    document.getElementById("xp-progress").style.width = progress + "%";
}

// Ajouter des XP
document.getElementById("add-xp").addEventListener("click", function() {
    userXP += 10;  // Augmenter l'XP de 10
    if (userXP >= 100) {
        userXP = 0;
        userLevel++;
    }
    updateProgress();
});

// Initialiser l'affichage
updateProgress();
