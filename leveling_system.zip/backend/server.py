
from flask import Flask, jsonify, request
from database import get_user_data, update_user_data

app = Flask(__name__)

@app.route('/get_user/<user_id>', methods=['GET'])
def get_user(user_id):
    user_data = get_user_data(user_id)
    return jsonify(user_data)

@app.route('/update_user/<user_id>', methods=['POST'])
def update_user(user_id):
    new_xp = request.json.get('xp')
    new_level = request.json.get('level')
    update_user_data(user_id, new_xp, new_level)
    return jsonify({"status": "success"})

if __name__ == '__main__':
    app.run(debug=True)
