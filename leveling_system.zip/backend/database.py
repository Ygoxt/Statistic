
import json

def get_user_data(user_id):
    with open('data/users.json', 'r') as f:
        data = json.load(f)
    return data.get(user_id, {"xp": 0, "level": 1})

def update_user_data(user_id, xp, level):
    with open('data/users.json', 'r') as f:
        data = json.load(f)
    data[user_id] = {"xp": xp, "level": level}
    with open('data/users.json', 'w') as f:
        json.dump(data, f)
